<?php

    /*
        Tabla de Usuarios.

        Es un array donde cada elemento es un objeto de la clase
        Usuario.
    */

    class arrayJugadores {

        
        
    }

?>