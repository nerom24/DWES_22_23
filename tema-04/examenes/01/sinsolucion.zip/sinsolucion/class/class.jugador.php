<?php

    /*
        Clase usuarios
    */

    Class Jugador {

        
    }

?>