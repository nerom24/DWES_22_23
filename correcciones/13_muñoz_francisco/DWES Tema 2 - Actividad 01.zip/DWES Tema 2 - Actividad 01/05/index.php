<?php

/* Ejercicio 5.

Hacer un programa que muestre en pantalla información de PHP con la función phpinfo(). Muestre la información centrada horizontalmente en la pantalla. */



    phpinfo(); // (Lo centra automáticamente)

?>