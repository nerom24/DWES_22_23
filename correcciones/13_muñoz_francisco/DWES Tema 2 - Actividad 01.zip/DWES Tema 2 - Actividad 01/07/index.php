<!-- Ejercicio 7.

A partir del ejercicio anterior, crear un párrafo en el que se cuente una pequeña historia o descripción con los datos de dicha variables. Colocar un título. -->

<?php

    $nombre = "Francisco";
    $apellidos = "Muñoz Carrasco";
    $poblacion = "Puerto Real";
    $edad = "31";
    $ciclo = "DAW";
    $curso = "2º";
    $modulo = "DWES";

    $titulo = "UNA PEQUEÑA DESCRIPCIÓN";
    $texto = "Mi nombre es $nombre $apellidos, tengo $edad años y vivo en $poblacion. Actualmente estoy en el $curso curso del ciclo de $ciclo, cursando el módulo de $modulo.";
    
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DWES Tema 2 - Actividad 1</title>
</head>
<body>
    
    <h1><?php echo "DWES TEMA 2 - ACTIVIDAD 1";?></h1>

    <table>
        <tr>
            <td>CAMPO</td>
            <td>VALOR</td>
        </tr>
        <tr>
            <td>Nombre:</td>
            <td><?=$nombre;?></td>
        </tr>
        <tr>
            <td>Apellidos:</td>
            <td><?=$apellidos;?></td>
        </tr>
        <tr>
            <td>Población:</td>
            <td><?=$poblacion;?></td>
        </tr>
        <tr>
            <td>Edad:</td>
            <td><?=$edad;?></td>
        </tr>
        <tr>
            <td>Ciclo:</td>
            <td><?=$ciclo;?></td>
        </tr>
        <tr>
            <td>Curso:</td>
            <td><?=$curso;?></td>
        </tr>
        <tr>
            <td>Módulo:</td>
            <td><?=$modulo;?></td>
        </tr>
    </table>


    <h2><?=$titulo;?></h2>
    <p><?=$texto;?></p>
    
</body>
</html>