<?php

/* Ejercicio 4.

Crear en un script PHP que cree dos variables una de tipo float y otra de tipo int. Almacenar en nuevas variables el resultado de la suma, resta, división, producto y potencia. Mostrar mediante var_dump() las variables con los resultados de las operaciones anteriores. */

    $tipoFloat = 12.5;
    $tipoInt = 5;

    echo "Suma: " . $suma = $tipoFloat + $tipoInt;
    var_dump($suma);

    echo "Resta: " . $resta = $tipoFloat - $tipoInt;
    var_dump($resta);

    echo "División: " . $division = $tipoFloat / $tipoInt;
    var_dump($division);

    echo "Producto: " . $producto = $tipoFloat * $tipoInt;
    var_dump($producto);

    echo "Potencia: " . $potencia = $tipoFloat ** $tipoInt;
    var_dump($potencia);

?>