<?php

/* Ejercicio 3.

Crear dos variables de tipo string y concatenar. Guardar resultado en nueva variable y mostrar resultado.*/


    $cadena1 = "Hola";
    $cadena2 = "Mundo";

    $cadena3 = $cadena1.$cadena2;

    echo $cadena3;


?>