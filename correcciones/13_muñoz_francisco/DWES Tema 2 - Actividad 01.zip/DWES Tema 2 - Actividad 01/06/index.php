<!-- Ejercicio 6.

Crear un programa PHP en el que se declaren las siguientes variables: Nombre, Apellidos, Población, Edad, Ciclo, Curso y Módulo. Asignar valor a dichas variables. Insertar un título en la cabecera de la página y mostrar los valores de dichas variables en una tabla a dos columnas (Campo y Valor). -->

<?php

    $nombre = "Francisco";
    $apellidos = "Muñoz Carrasco";
    $poblacion = "Puerto Real";
    $edad = "31";
    $ciclo = "DAW";
    $curso = "2º";
    $modulo = "DWES";
    
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DWES Tema 2 - Actividad 1</title>
</head>
<body>
    
    <h1><?php echo "DWES TEMA 2 - ACTIVIDAD 1";?></h1>

    <table>
        <tr>
            <td>CAMPO</td>
            <td>VALOR</td>
        </tr>
        <tr>
            <td>Nombre:</td>
            <td><?=$nombre;?></td>
        </tr>
        <tr>
            <td>Apellidos:</td>
            <td><?=$apellidos;?></td>
        </tr>
        <tr>
            <td>Población:</td>
            <td><?=$poblacion;?></td>
        </tr>
        <tr>
            <td>Edad:</td>
            <td><?=$edad;?></td>
        </tr>
        <tr>
            <td>Ciclo:</td>
            <td><?=$ciclo;?></td>
        </tr>
        <tr>
            <td>Curso:</td>
            <td><?=$curso;?></td>
        </tr>
        <tr>
            <td>Módulo:</td>
            <td><?=$modulo;?></td>
        </tr>
    </table>
    
</body>
</html>