<!-- Ejercicio 2.

Añadir al ejercicio anterior una imagen relacionada con la noticia. -->

<?php
    $texto = "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.";
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DWES Tema 2 - Actividad 1</title>
</head>
<body>
    
    <h1><?php echo "DWES Tema 2 - Actividad 1";?></h1>
    
    <p><?=$texto;?></p>
    
    <?php echo '<a href="https://elpais.com/">El País</a>';?>

    <?php echo '<img src="https://static.elpais.com/dist/resources/images/logos/primary/el-pais.svg">';?>
    
</body>
</html>