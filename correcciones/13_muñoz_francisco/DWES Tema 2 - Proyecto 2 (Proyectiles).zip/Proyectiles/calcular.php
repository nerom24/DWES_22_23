<?php

    define ("GRAVEDAD", 9.8); 
    $velocidad = $_POST['velocidad'];
    $angulo = $_POST['angulo'];
    

    //Ángulo en Radianes (A0)
    $aRadianes = round(deg2rad($angulo), 5);

    //Velocidad Inicial Horizontal (Vox) m/s
    $vox = round($velocidad * cos($aRadianes), 2);

    //Velocidad Inicial Vertical (Voy) m/s
    $voy = round($velocidad * sin($aRadianes), 2);

    //El alcance máximo (Xmax) metros
    $xMax = round((pow($velocidad, 2) * sin(2 * $aRadianes)) / GRAVEDAD, 2);

    //Altura máxima alcanzada por el proyectil (Ymax) metros
    $yMax = round((pow($velocidad, 2) * pow(sin($aRadianes), 2)) / (2 * GRAVEDAD), 2);

    //Tiempo total en vuelo (t) segundos
    $t = round(2 * ($voy / GRAVEDAD) , 2);


    $velocidadX = number_format($vox, 2, ",",".");
    $velocidadY = number_format($voy, 2, ",",".");
    $radianes = number_format($aRadianes, 5, ",",".");
    $xMaximo = number_format($xMax, 2, ",",".");
    $yMaximo = number_format($yMax, 2, ",",".");
    $tiempo = number_format($t, 2, ",",".");


    include "resultado.php";

?>