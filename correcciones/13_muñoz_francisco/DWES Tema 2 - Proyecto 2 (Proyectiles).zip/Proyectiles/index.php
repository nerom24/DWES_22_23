<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DWES Tema 2 - Proyecto Proyectiles</title>

    <!-- Bootstrap css -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">

    <!-- Bootstrap Icons 1.9.1 -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css" integrity="sha384-xeJqLiuOvjUBq3iGOjvSQSIlwrpqjSHXpduPd6rQpuiM3f5/ijby8pCsnbu5S81n" crossorigin="anonymous">
</head>
<body>
    <!-- Capa Principal -->
    
    <div class="container">

        <header class="pb-3 mb-4 border-bottom">
            <i class="bi bi-app-indicator"></i>        
            <span class="fs-4">Proyecto - Tema 2 DWES 20/21</span>
        </header>

        <h1>Lanzamiento Proyectiles</h1>
        <hr>
        
        <form method="POST">
            <div class="mb-3">
                <label for="" class="form-label">Velocidad Inicial:</label>
                <input type="number" name="velocidad" class="form-control" placeholder="" aria-describedby="helpId" step="0.01" value="0">
                <small id="helpId" class="text-muted">Velocidad en m/s</small>
            </div>

            <div class="mb-3">
                <label for="" class="form-label">Ángulo Lanzamiento:</label>
                <input type="number" name="angulo" class="form-control" placeholder="" aria-describedby="helpId" step="0.01" value="0">
                <small id="helpId" class="text-muted">Ángulo en grados</small>
            </div>

            <div class="btn-group" role="group">
                <button type="reset" class="btn btn-outline-secondary">Borrar</button>
                <button type="submit" class="btn btn-outline-secondary" formaction="calcular.php">Calcular</button>
            </div>
        </form>

    </div>

    <!-- Pie del documento -->
    <footer class="footer mt-auto py-3 fixed-bottom bg-light">
        <div class="container">
            <span class="text-muted">© 2022
                Francisco de Asís Muñoz - DWES - 2º DAW - Curso 22/23</span>
        </div>
    </footer>

    <!-- Bootstrap Javascript y popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3" crossorigin="anonymous"></script>
 
</body>
</html>