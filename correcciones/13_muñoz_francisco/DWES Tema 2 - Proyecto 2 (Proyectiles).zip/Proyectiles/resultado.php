<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DWES Tema 2 - Proyecto Proyectiles</title>

    <!-- Bootstrap css -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">

    <!-- Bootstrap Icons 1.9.1 -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css" integrity="sha384-xeJqLiuOvjUBq3iGOjvSQSIlwrpqjSHXpduPd6rQpuiM3f5/ijby8pCsnbu5S81n" crossorigin="anonymous">
</head>
<body>
    <!-- Capa Principal -->
    
    <div class="container">

        <header class="pb-3 mb-4 border-bottom">
            <i class="bi bi-app-indicator"></i>        
            <span class="fs-4">Proyecto - Tema 2 DWES 20/21</span>
        </header>

        <h1>Lanzamiento Proyectiles</h1>
        <hr>
        <legend>Resultado</legend>
        <table class="table table-light">
            <tbody>
                <tr>
                    <th scope="row">Valores Iniciales:</th>
                </tr>
                <tr>
                    <td scope="row">Velocidad Inicial:</td>
                    <td><?=$velocidad ?> m/s</td>
                </tr>
                <tr>
                    <td scope="row">Ángulo Inicial:</td>
                    <td><?=$angulo ?> º</td>
                </tr>
                <tr>
                    <th scope="row">Resultados:</td>
                </tr>
                <tr>
                    <td scope="row">Ángulo Radianes:</td>
                    <td><?=$radianes ?> Radianes</td>
                </tr>
                <tr>
                    <td scope="row">Velocidad Inicial X:</td>
                    <td><?=$velocidadX ?> m/s</td>
                </tr>
                <tr>
                    <td scope="row">Velocidad Inicial X:</td>
                    <td><?=$velocidadY ?> m/s</td>
                </tr>
                <tr>
                    <td scope="row">Alcance Máximo del Proyectil:</td>
                    <td><?=$xMaximo ?> m</td>
                </tr>
                <tr>
                    <td scope="row">Tiempo de Vuelo del Proyectil:</td>
                    <td><?=$tiempo ?> s</td>
                </tr>
                <tr>
                    <td scope="row">Altura Máxima del Proyectil:</td>
                    <td><?=$yMaximo ?> m</td>
                </tr>
            </tbody>
        </table>

    </div>

    <!-- Pie del documento -->
    <footer class="footer mt-auto py-3 fixed-bottom bg-light">
        <div class="container">
            <span class="text-muted">© 2022
                Francisco de Asís Muñoz - DWES - 2º DAW - Curso 22/23</span>
        </div>
    </footer>

    <!-- Bootstrap Javascript y popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3" crossorigin="anonymous"></script>
 
</body>
</html>