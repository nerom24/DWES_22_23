<?php

    $numero = $_POST['numero'];
    $base = (int)($_POST['base']);
    $baseConver = (int)($_POST['baseConver']);

    $numeroConvertido = (float)(base_convert($numero, $base, $baseConver));

?>