<?php

    include ("views/view.index.php");

?>