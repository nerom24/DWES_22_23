<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DWES Tema 2 - Examen Práctico</title>

    <!-- Bootstrap css -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">

    <!-- Bootstrap Icons 1.9.1 -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css" integrity="sha384-xeJqLiuOvjUBq3iGOjvSQSIlwrpqjSHXpduPd6rQpuiM3f5/ijby8pCsnbu5S81n" crossorigin="anonymous">
</head>
<body>
    <!-- Capa Principal -->
    
    <div class="container">

        <header class="pb-3 mb-4 border-bottom">
            <i class="bi bi-app-indicator"></i>        
            <span class="fs-4">Examen Práctico - Tema 2. Inserción de código en páginas web</span>
        </header>

        <h3>Conversión entre Sistemas Numéricos</h3>
        <form method="POST">
            <div class="mb-3">
                <label for="" class="form-label">Número</label>
                <input type="number" name="numero" class="form-control" placeholder="" aria-describedby="helpId" value="<?=$numero ?>" readonly="readonly">
            </div>

            <div class="mb-3">
                <label for="" class="form-label">Base</label>
                <input type="number" name="base" class="form-control" placeholder="" aria-describedby="helpId" value="<?=$base ?>" readonly="readonly">
            </div>

            <div class="mb-3">
                <label for="" class="form-label">Convertir a base</label>
                <input type="number" name="baseConver" class="form-control" placeholder="" aria-describedby="helpId" value="<?=$baseConver ?>" readonly="readonly">
            </div>

            <div class="mb-3">
                <label for="" class="form-label">Conversión</label>
                <input type="number" name="conversion" class="form-control" placeholder="" aria-describedby="helpId" value="<?=$numeroConvertido ?>" readonly="readonly">
            </div>

            <div class="btn-group" role="group">
                <button type="submit" class="btn btn-outline-secondary" formaction="index.php">Nueva Conversión</button>
            </div>
        </form>
    </div>
    <!-- Pie del documento -->
    <footer class="footer mt-auto py-3 fixed-bottom bg-light">
        <div class="container">
            <span class="text-muted">© 2022
                Francisco de Asís Muñoz - DWES - 2º DAW - Curso 22/23</span>
        </div>
    </footer>

    <!-- Bootstrap Javascript y popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3" crossorigin="anonymous"></script>
 
</body>
</html>