<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="<?= URL ?>public/bootstrap-5.1.1-dist/js/bootstrap.bundle.min.js"></script>