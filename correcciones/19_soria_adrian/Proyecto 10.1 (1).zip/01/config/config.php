<?php
# Configuración básica aplicación MVC

# Ruta absoluta


define('URL', 'http://localhost/dwes/tema-10/proyectos/01/');

# Constante de la Base de Datos
define('HOST', 'localhost');
define('DB', 'gesbank');
define('USER', 'root');
define('PASSWORD', '');
define('CHARSET', 'utf8mb4');


?>