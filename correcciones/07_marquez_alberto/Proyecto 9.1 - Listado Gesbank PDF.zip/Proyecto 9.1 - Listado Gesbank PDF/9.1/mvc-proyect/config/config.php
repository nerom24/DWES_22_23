<?php

define('URL', 'http://localhost/DWES/Tema-09/Proyectos/Proyecto%209.1%20-%20Listado%20Gesbank%20PDF/9.1/mvc-proyect/');
define('HOST', 'localhost');
define('DB', 'gesbank');
define('USER', 'root');
define('PASSWORD', '');
define('CHARSET', 'utf8mb4');
