<?php
#|---------------------------|
#| DATOS DE LA BASE DE DATOS |
#|---------------------------|
define('URL', 'http://localhost/DWES/Tema-08/Proyectos/8.1%20Gestor%20Album%20de%20fotograf%c3%adas%20web/');
define('HOST', 'localhost');
define('DB', 'album');
define('USER', 'root');
define('PASSWORD', '');
define('CHARSET', 'utf8mb4');
#-------------------------------------------------------------------------------------------------------------
?>