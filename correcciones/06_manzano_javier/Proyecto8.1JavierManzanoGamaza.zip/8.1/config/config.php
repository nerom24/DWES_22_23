<?php

define('URL', 'http://localhost/dwes/Tema-07/Proyectos/8.1/');

# Constante de la Base de Datos
define('HOST', 'localhost');
define('DB', 'album');
define('USER', 'root');
define('PASSWORD', '');
define('CHARSET', 'utf8mb4');

?>