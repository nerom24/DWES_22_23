<header>
    <hgroup>
        <!-- Titulos y subtitulos -->
        <div class="jumbotron jumbotron-fluid">
            <div class="container"><br><br>
                <h4 class="display-7"><?= $this->title ?> </h4>
                <p class="lead">GESBANK</p>
            </div>
        </div>
    </hgroup>
</header>