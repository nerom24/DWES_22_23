<?php

define('URL', 'http://localhost/DWES/Tema-10/Proyectos/Proyecto%2010.1/');

# Constante de la Base de Datos
define('HOST', 'localhost');
define('DB', 'gesbank');
define('USER', 'root');
define('PASSWORD', '');
define('CHARSET', 'utf8mb4');
