<header>
    <hgroup>
        <!-- Titulos y subtitulos -->
        <div class="jumbotron jumbotron-fluid">
        <div class="container">
            <h4 class="display-7">Gestion Bancaria - GESBANK </h4>
            <p class="lead">Fase 2 proyecto</p>
        </div>
        </div>
    </hgroup>
</header>