<?php


define('URL', 'http://localhost/dwes/proyectos/9.1/');

define('HOST', 'localhost');
define('DB', 'gesbank');
define('USER', 'root');
define('PASSWORD', '');
define('CHARSET', 'utf8mb4');
