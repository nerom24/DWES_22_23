<?php

define('URL', 'http://localhost/dwes/tema-10/Proyectos/ProyectoGesbank/');
define('HOST', 'localhost');
define('DB', 'gesbank');
define('USER', 'root');
define('PASSWORD', '');
define('CHARSET', 'utf8mb4');
