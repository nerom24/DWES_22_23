<?php

define('URL', 'http://localhost/dwes/tema-09/Proyectos/ProyectoGesbank/');
define('HOST', 'localhost');
define('DB', 'gesbank');
define('USER', 'root');
define('PASSWORD', '');
define('CHARSET', 'utf8mb4');
