<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="<?= URL ?>public/bootstrap-5.2.3-dist/js/bootstrap.bundle.min.js"></script>