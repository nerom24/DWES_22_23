<header>
    <hgroup>
        <!-- Titulos y subtitulos -->
        <div class="jumbotron jumbotron-fluid">
            <div class="container"><br><br><br>
                <h1 class="display-7"><?= $this->title ?> </h1>
                <p class="lead">Albumes</p>
            </div>
        </div>
    </hgroup>
</header>