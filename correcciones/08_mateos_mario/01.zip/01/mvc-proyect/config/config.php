<?php

define('URL', 'http://localhost/dwes/tema-08/Proyectos/01/mvc-proyect/');

# Constante de la Base de Datos
define('HOST', 'localhost');
define('DB', 'album');
define('USER', 'root');
define('PASSWORD', '');
define('CHARSET', 'utf8mb4');
