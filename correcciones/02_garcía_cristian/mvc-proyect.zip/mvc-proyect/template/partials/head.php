<head>
    <title>Modelo Vista Controlador</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?= URL ?>public/bootstrap-5.2.3-dist/css/bootstrap.min.css">

    
    <!-- Bottstrap icons 1.9 -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.2/font/bootstrap-icons.css">
    <!-- Estilo Personalizado -->
    <link href="<?= URL ?>public/style.css" rel="stylesheet">   
</head>