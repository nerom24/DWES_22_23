<?php

    

    $GLOBALS ['crear'] = [1, 2];
    $GLOBALS ['editar'] = [1, 2];
    $GLOBALS ['eliminar'] = [1];
    $GLOBALS ['mostrar'] = [1, 2, 3];
    $GLOBALS ['buscar'] = [1, 2, 3];
    $GLOBALS ['ordenar'] = [1, 2,3];

    define( "ADMIN", 1);
?>