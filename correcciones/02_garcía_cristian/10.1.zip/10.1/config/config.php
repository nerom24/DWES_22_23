<?php


define('URL', 'http://localhost/dwes/tema-010/proyectos/10.1/');

define('HOST', 'localhost');
define('DB', 'gesbank');
define('USER', 'root');
define('PASSWORD', '');
define('CHARSET', 'utf8mb4');
