<?php

define('URL', 'http://localhost/dwes/tema-09/proyectos/9.1/mvc-proyect/');

# Constante de la Base de Datos
define('HOST', 'localhost');
define('DB', 'gesbank');
define('USER', 'root');
define('PASSWORD', '');
define('CHARSET', 'utf8mb4');
